# MultiPing v1.6 Installation Troubleshooting

## 🚨 If the Installer Doesn't Work

### **Step 1: Check the Log File**
After running the installer, look for a file called `MultiPing-Installer.log` in the same folder. This contains detailed debugging information.

### **Step 2: Manual Installation**
If the installer fails, you can install manually:

1. **Open Terminal** (Applications → Utilities → Terminal)
2. **Navigate** to the MultiPing folder:
   ```bash
   cd /path/to/MultiPing-v1.6-Release
   ```
3. **Make executable**:
   ```bash
   chmod +x MultiPing-v1.6-release
   ```
4. **Run MultiPing**:
   ```bash
   ./MultiPing-v1.6-release
   ```

### **Step 3: Common Issues**

#### **"Permission Denied"**
- Right-click the installer and select "Open"
- Or use the manual installation method above

#### **"File Not Found"**
- Make sure you extracted the entire zip file
- Check that `MultiPing-v1.6-release` is in the same folder as the installer

#### **"Cannot be opened because it is from an unidentified developer"**
- Go to System Preferences → Security & Privacy
- Click "Open Anyway" for MultiPing

### **Step 4: Get Help**
If you're still having issues:

1. **Save the log file** (`MultiPing-Installer.log`)
2. **Note your macOS version** (Apple menu → About This Mac)
3. **Contact support** with the log file and system info

## 📱 Running MultiPing

Once installed, MultiPing will appear in your menubar (top-right of screen). Click the icon to access all features.

## 🔧 System Requirements

- **macOS 12.0 (Monterey)** or later
- **No additional software** required
- **No dependencies** to install
